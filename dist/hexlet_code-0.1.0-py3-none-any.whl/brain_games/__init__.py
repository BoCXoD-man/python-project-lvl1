"""Brain games package."""
