#!/usr/bin/env python
""" Main Module"""
from brain_games.engine import start


def main():
    """ Main program"""
    start()


if __name__ == '__main__':
    main()
