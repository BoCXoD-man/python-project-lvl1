#!/usr/bin/env python
"""Game even or no even"""

from brain_games.engine import brain_even


def main():
    """Start Brain_Even"""
    brain_even()


if __name__ == '__main__':
    main()
